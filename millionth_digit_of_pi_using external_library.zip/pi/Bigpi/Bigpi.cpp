//============================================================================
// Name        : Bigpi.cpp
// Author      : Prashanth_Rajasekar
// Version     :
// Copyright   : 3 major functions - compute_yi, compute_ai, output.
// Description : computes 1000 precision of pi
//============================================================================

#include <iostream>
#include <iomanip>
#include <mpir.h>
#include <stdlib.h>
#include <string.h>
#include <chrono>

using namespace std;
using namespace std::chrono;

const int MAX_ITERATIONS = 5;
const int PLACES         = 1000;        // desired decimal places
const int PRECISION      = PLACES + 1;  // +1 for the digit 3 before the decimal

const int BASE       = 10;  // base 10 numbers
const int BIT_COUNT  = 8;   // bits per machine word

const int BLOCK_SIZE = 10;                // print digits in blocks
const int LINE_SIZE  = 100;               // digits to print per line
const int LINE_COUNT = PLACES/LINE_SIZE;  // lines to print
const int GROUP_SIZE = 5;                 // line grouping size

void compute_yi(mpf_t& y_next, mpf_t& y0_var);

void compute_ai(mpf_t& a_next,mpf_t& y_next, mpf_t& a0_var);

void output(char* str, int index);

mpf_t one_value, two_value, four_value, six_value, tp2ip1; //variables will be accessible globally
int main(){
	steady_clock::time_point start_time = steady_clock::now();

	//////////////// useful numbers defined below //////////////////
	mpf_init(one_value);
	mpf_set_str(one_value,  "1", BASE);

	mpf_init(two_value);
	mpf_set_str(two_value,  "2", BASE);

	mpf_init(four_value);
	mpf_set_str(four_value, "4", BASE);

	mpf_init(six_value);
	mpf_set_str(six_value,  "6", BASE);

	mpf_init(tp2ip1); //2, 8, 32, 128, 512 and so on.
	mpf_set_str(tp2ip1, "2", BASE); //converges to 2power2i + 1 as the loop iterates.
	////////////////////////////////////////////////////////////////

	mpf_set_default_prec(BIT_COUNT*PRECISION); //precision dialogue

    	mpf_t root2;
    	mpf_init(root2);
    	mpf_sqrt(root2, two_value); // root2=2^(1/2);

    	mpf_t four_mul_root2;
    	mpf_init(four_mul_root2);
    	mpf_mul(four_mul_root2, four_value, root2); // 4*root2;

    	mpf_t y0_var;
    	mpf_init(y0_var);
    	mpf_sub(y0_var, root2, one_value); //root2 - 1;

    	mpf_t a0_var;
    	mpf_init(a0_var);
    	mpf_sub(a0_var, six_value, four_mul_root2); // 6-4root2;

    	mpf_t y_next;
    	mpf_init(y_next);

    	mpf_t a_next;
    	mpf_init(a_next);

    	//cout << endl;
    	for (int i = 1; i <= MAX_ITERATIONS; i++) // loop will run for 5 times.
    	{
    		compute_yi(y_next, y0_var); // function called to compute yi.
    		compute_ai(a_next, y_next, a0_var); //function called to comput ai.

    		mpf_set(a0_var, a_next); //sets the new a value to the old a0_var variable for each iteration.
    		mpf_set(y0_var, y_next); ////sets the new y value to the old variable y0_var for each iteration.
    	}

    	mpf_t pie;
    	mpf_init(pie);
    	mpf_div(pie, one_value, a_next); // pie=1/a;

    	mp_exp_t exponent;
    	char* str= mpf_get_str(NULL,&exponent,BASE,PRECISION,pie);
    	int index=0;
    	cout<<"pi to 1000 places:"<<endl;
    	cout<<endl;
    	cout<<str[index];
    	cout<<".";
    	index=index+1;

	steady_clock::time_point end_time = steady_clock::now();// time calculated only for compute pi.

    	output(str, index); //function to show the output.

    	float elapsed_time=duration_cast<microseconds>(end_time - start_time).count();
    	elapsed_time=elapsed_time/1000000;
    	cout.precision(6);
    	cout<<"Elapsed time: "<<fixed<<elapsed_time<<" seconds"<<endl;
    	return 0;
}
void compute_yi(mpf_t& y_next, mpf_t& y0_var){
	mpf_t y0_square;
 	mpf_init(y0_square);
    	mpf_mul(y0_square, y0_var, y0_var); // y0^2;
	mpf_t y0_quad;
	mpf_init(y0_quad);
	mpf_mul(y0_quad, y0_square, y0_square); //y0^4;
	mpf_t one_y0p4;
	mpf_init(one_y0p4);
	mpf_sub(one_y0p4, one_value, y0_quad); 	//(1 - y0^4);
	mpf_t sqrt_one_y0p4;
	mpf_init(sqrt_one_y0p4);
	mpf_t quadrt_one_y0p4;
	mpf_init(quadrt_one_y0p4);
	mpf_sqrt(sqrt_one_y0p4, one_y0p4);			//sqrt(1-y0^4);
	mpf_sqrt(quadrt_one_y0p4, sqrt_one_y0p4);		//4throot(1-y0^4);
	mpf_t numerator, denominator;
	mpf_init(numerator);
	mpf_init(denominator);
	mpf_sub(numerator, one_value,quadrt_one_y0p4 );
	mpf_add(denominator, one_value, quadrt_one_y0p4);
	mpf_div(y_next, numerator, denominator); // y=numerator/denominator;
}

void compute_ai(mpf_t& a_next,mpf_t& y_next, mpf_t& a0_var){
	mpf_t one_p_y_next;
	mpf_init(one_p_y_next);
	mpf_t quad_one_p_y_next;
	mpf_init(quad_one_p_y_next);
	mpf_t sq_one_p_y_next;
	mpf_init(sq_one_p_y_next);
	mpf_add(one_p_y_next, one_value, y_next);
	mpf_mul(sq_one_p_y_next, one_p_y_next, one_p_y_next);// (1+y)^2;
	mpf_mul(quad_one_p_y_next, sq_one_p_y_next, sq_one_p_y_next);// (1 + y)^4;
	mpf_t left_half;
	mpf_init(left_half);
	mpf_mul(left_half, a0_var, quad_one_p_y_next); // a0_var*(1 + y)power4;
	mpf_mul(tp2ip1, four_value, tp2ip1); //value changes to 8, 32, 128, 512........
	mpf_t yi_square;
	mpf_init(yi_square);
	mpf_mul(yi_square, y_next, y_next); // yi^2=yi*yi;
	mpf_t right_half;
	mpf_init(right_half);
	mpf_t one_p_y_next_copy;
	mpf_init(one_p_y_next_copy);
	mpf_add(one_p_y_next_copy, one_value, y_next);// 1+yi;
	mpf_t one_p_y_next_p_yi_square;
	mpf_init(one_p_y_next_p_yi_square);
	mpf_add(one_p_y_next_p_yi_square, one_p_y_next_copy, yi_square); // 1+yi+yi^2;
	mpf_mul(right_half, one_p_y_next_p_yi_square, y_next); // yi(1+yi+yi^2);
	mpf_mul(right_half, right_half, tp2ip1); // 2^(2i+1)*(yi(1+yi+yi^2));
	mpf_sub(a_next, left_half, right_half); //ai=lefthalf-righthalf;
}

void output(char* str, int index){
	for(int i=1;i<=LINE_COUNT;i++){
	    	for(int j=1;j<=LINE_SIZE;j++){
	    		cout<<str[index];
	    		index++;
	    		if((index-1)%BLOCK_SIZE==0){
	    			cout<<" ";
	    		}
	    	}
	    	if(i%GROUP_SIZE==0){
	    		cout<<endl;
	    	}
	    	cout<<endl<<"  ";
	 }
}
