#ifndef ROMANNUMERAL_H_
#define ROMANNUMERAL_H_

#include<string>
using namespace std;
class RomanNumeral
{
private:
   //string to store roman numerals.
    string roman;

   //integer variable to store decimal values.
    int decimal;

   //private member function to convert roman to decimal.
    int to_decimal(string temporary_string) const;

   //private member function to convert decimal to roman.
    string to_roman(int temporary_decimal );

public:
    //default constructor
    RomanNumeral();

    //constructor with string intake.
    RomanNumeral(string string_value);

    //constructor with integer intake.
    RomanNumeral(int decimal_value);

    //getter function that returns string
    string getter_roman_function();

    	//getter function that returns integer.
    int getter_decimal_function();

    //converter function converts each character to its respective integers.
    int converter(char temp_array) const;


    //all the below functions are defined and declared outside the class,
    //these variables can still access the private variable, as they are
    //friend of this class. these functions are also known as non member
    //functions.

    //function to overload "<<" operator.
    friend ostream& operator <<(ostream& output, const RomanNumeral & object);

    //function to overload ">>" operator.
    friend istream& operator >>(istream& input,  RomanNumeral & object);

    //function to overload "+" operator.
    friend int operator +(const RomanNumeral& object1, const RomanNumeral& object2);

    //function to overload "/" operator.
    friend int operator /(const RomanNumeral& object1, const RomanNumeral& object2);

    //function to overload "==" operator.
    friend bool operator ==(const RomanNumeral& object1, const RomanNumeral& object2);

    //function to overload "!=" operator.
    friend bool operator !=(const RomanNumeral& object1, const RomanNumeral& object2);

    //function to overload "-" operator.
    friend int operator -(const RomanNumeral& object1, const RomanNumeral& object2);

    //function to overload "*" operator.
    friend int operator *(const RomanNumeral& object1, const RomanNumeral& object2);



};

#endif /* ROMANNUMERAL_H_ */
