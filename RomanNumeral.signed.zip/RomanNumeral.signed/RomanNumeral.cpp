//============================================================================
// Name        : Roman.cpp
// Author      : Prashanth_Rajasekar
// Version     :
// Copyright   : Roman_Numbers
// Description : 7 friend functions, 2 private member functions, 5 public member functions.
//============================================================================

#include<string>
#include<iostream>
#include <fstream>
#include"RomanNumeral.h"
using namespace std;

//getter function that returns string values.
string RomanNumeral::getter_roman_function() {
	return roman;
}

//getter function that returns integer values.
int RomanNumeral::getter_decimal_function() {
	return decimal;
}

//definition of default constructor.
RomanNumeral::RomanNumeral() { 
	roman="";
	decimal=0;
}
//constructor with string intake
RomanNumeral:: RomanNumeral(string string_value){
    roman = string_value;
    decimal = to_decimal(roman); //private member function called.
}

//constructor with integer intake.
RomanNumeral :: RomanNumeral(int decimal_value){
    decimal = decimal_value;
    roman = ""; 		//for safety purpose, emptying the string before using.
    roman = to_roman(decimal); //private member function called.
}

//definition of private member function.
string RomanNumeral:: to_roman(int temporary_decimal){ 
    char temp_char_array[9]; //temporary array declared to store the meantime characters.
    int index=0; //index of the temporary array. it will go maximum up to 9, we require only till 8.
    int concat_times=0; //number of time the letter will be added to the temporary array.
    int iterator=0;
    while (temporary_decimal > 0){	//decimal value passed to the function should be greater than 0.
    	//below is the classification of various sets of numbers according to the Roman characters.
    		if (temporary_decimal >= 1000){ // M=1000
            concat_times=0;
            	while(concat_times<temporary_decimal/1000){ //loop will add 'M' to array 'temp_char_array' until 'number/1000' times.
            		temp_char_array[index++] = 'M';
            		concat_times++;
            	}
            	temporary_decimal = temporary_decimal%1000;
        }
        else if (temporary_decimal >= 500){ //D=500
            if (temporary_decimal < 900){
            	concat_times=0;
                while(concat_times<temporary_decimal/500){//loop will add 'D' to array 'temp_char_array' until 'number/500' times.
                		temp_char_array[index++] = 'D'; //=500
                		concat_times++;
                }
                temporary_decimal = temporary_decimal%500;
            }
            else{
            		temp_char_array[index++] = 'C'; //C=100
            		temp_char_array[index++] = 'M'; //M=1000
            		temporary_decimal = temporary_decimal%100 ;
            }
        }
        else if (temporary_decimal >= 100){ //C=100
            if (temporary_decimal < 400){
            	concat_times=0;
            		while(concat_times<temporary_decimal/100){//loop will add 'C' to array 'temp_char_array' until 'number/100' times.
            			temp_char_array[index++] = 'C'; //=100
            			concat_times++;
            		}
            		temporary_decimal = temporary_decimal%100;
            }
            else{
            		temp_char_array[index++] = 'C'; //C=100
            		temp_char_array[index++] = 'D'; //D=500
            		temporary_decimal = temporary_decimal%100;
            }
        }
        else if (temporary_decimal >= 50 ){ //L=50
            if (temporary_decimal < 90){
            	concat_times=0;
            	    while(concat_times<temporary_decimal/50){//loop will add 'L' to array 'temp_char_array' until 'number/50' times.
            	    		temp_char_array[index++] = 'L'; //=50
            	    		concat_times++;
            	    }
            	    temporary_decimal = temporary_decimal%50;
            }
            else{
            		temp_char_array[index++] = 'X'; //X=10
            		temp_char_array[index++] = 'C'; //C=100
            		temporary_decimal = temporary_decimal%10;
            }
        }
        else if (temporary_decimal >= 10){ //X=10;
            if (temporary_decimal < 40){
            	concat_times=0;
            	    while(concat_times<temporary_decimal/10){//loop will add 'X' to array 'temp_char_array' until 'number/10' times.
            	    		temp_char_array[index++] = 'X'; //=10
            	    		concat_times++;
            	    }
            	    temporary_decimal = temporary_decimal%10;
            }
            else{
            		temp_char_array[index++] = 'X'; //X=10
            		temp_char_array[index++] = 'L'; //L=50
            		temporary_decimal = temporary_decimal%10;
            }
        }
        else if (temporary_decimal >= 5){ //V=5
            if (temporary_decimal < 9) {
            	concat_times=0;
            	    while(concat_times<temporary_decimal/5){//loop will add 'V' to array 'temp_char_array' until 'number/5' times.
            	    		temp_char_array[index++] = 'V'; //=5
            	    		concat_times++;
            	    }
            	    temporary_decimal = temporary_decimal % 5;
            }
            else{
            		temp_char_array[index++] = 'I'; //=1
            		temp_char_array[index++] = 'X'; //=10
            		temporary_decimal = 0;
            }
        }
        else if (temporary_decimal >= 1){ //I=1
            if (temporary_decimal < 4) {
            	concat_times=0;
            	    while(concat_times<temporary_decimal){//loop will add 'I' to array 'temp_char_array' until 'number' times.
            	    		temp_char_array[index++] = 'I'; //=1
            	    		concat_times++;
            	    }
            	    temporary_decimal = 0;
            }
            else{
            		temp_char_array[index++] = 'I'; //I=1
            		temp_char_array[index++] = 'V'; //V=5
            		temporary_decimal = 0;
            }
        }
    }
    string returning_string = ""; //for safety purpose, empty returning_string that stores the values.
    index=index-1; //we require 1 index less as mentioned above while declaring index variable.
    while(iterator<=index){//individual characters concatenated to the returning_string below.
    		returning_string = returning_string+temp_char_array[iterator];
    		iterator++;
     }
    	return returning_string;
}
//"to_decimal" function calls the "converter" function to convert each element to
//decimal and finds the total of it and add it to the total variable.
int RomanNumeral ::to_decimal (string temporary_string) const { //definition of private member function.
	int decimal_value;
	int total=0; //variable which is finally returned with the decimal value.
    int next_decimal_value=0;
    int i=0;
    	while(i<=temporary_string.length()-1){
    		decimal_value = converter( temporary_string[i] );
   		if (i<temporary_string.length() && decimal_value < converter( temporary_string[i+1] )){
   			next_decimal_value=converter(temporary_string[i+1]);
    			total+=next_decimal_value - decimal_value;
    			i++;
        	}
        	else{
        		total+=decimal_value;
       	}
       	i++;
    	}
    return total;
}
int RomanNumeral::converter(char temp_char) const {
	switch(temp_char){
	case 'I':		//I=1
		return 1;
	case 'V':		//V=5
		return 5;
	case 'X':		//X=10
		return 10;
	case 'L':		//L=50
		return 50;
	case 'C':		//C=100
		return 100;
	case 'D':		//D=500
		return 500;
	case 'M':		//M=1000
		return 1000;
	}
return 0;
}


/////////////////////////////////////////////////////////////////////////////////////////
//definition of overloading operator given below which are a nonmember functions that can
//still access the member variables.
//////////////////////////////////////////////////////////////////////////////////////////


//definition of overloading operator <<.
ostream& operator <<(ostream& output, const RomanNumeral& object){ 	//friend function.
    string rom=object.roman;
    int dec=object.decimal;
    if(rom[0]==' '){//condition to check for white spaces at index 0, if present or not?.
       rom.erase(0,1);//erasing the 0th index if any space is inserted by mistake.
    }
    output <<"["<<dec <<":"<<rom << "]";
    return output;
}

//definition of overloading operator /.
int operator /(const RomanNumeral& object1, const RomanNumeral& object2){ //friend function
	object1.to_decimal(object1.roman);
	object2.to_decimal(object2.roman);
    int return_value=object1.decimal/object2.decimal;
    return return_value;
}

//definition of overloading operator +.
int operator +(const RomanNumeral& object1, const RomanNumeral& object2){ //friend function
    int return_value=object1.decimal+object2.decimal;
    return return_value;
}

//definition of overloading operator == which is of bool type.
bool operator ==(const RomanNumeral& object1, const RomanNumeral& object2){//friend function
    return object1.decimal == object2.decimal;
}

//definition of overloading operator != which is of bool type.
bool operator !=(const RomanNumeral& object1, const RomanNumeral& object2){
    return object1.decimal != object2.decimal;
}

//definition of overloading operator >>.
istream& operator >>(istream& input,  RomanNumeral & object){	//friend function
    input >>object.roman;
    object.decimal= object.to_decimal(object.roman);
    return input;
}

//definition of overloading operator *.
int operator *(const RomanNumeral& object1, const RomanNumeral& object2){ //friend function
    int return_value=object1.decimal * object2.decimal;
    return return_value;
}

//definition of overloading operator -.
int operator -(const RomanNumeral& object1, const RomanNumeral& object2){ //friend function
    int return_value=object1.decimal - object2.decimal;
    return return_value;
}
