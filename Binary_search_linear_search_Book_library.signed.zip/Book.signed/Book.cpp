//============================================================================
// Name        : Book.cpp
// Author      : Prashanth_Rajasekar
// Version     :
// Copyright   : Book_Catalogue
// Description : Hello World in C++, Ansi-style
//============================================================================


#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <stdio.h>
#include "Book.h"

using namespace std;

Book::Book(){ //constructor initialises every variable to null//
    isbn_number="";
    last_name="";
    first_name="";
    title_name="";
    category=Category::NONE;
}

Book::Book(string isbn, string last, string first, string title, Category category_name){
     isbn_number=isbn; //constructor that takes input values//
     last_name=last;
     first_name=first;
     title_name=title;
     category=category_name;
}

Book::~Book(){} //destrucctor to destroy the allocated resources.

string Book::fetch_isbn_number()  const {
	return isbn_number;
}

string Book::fetch_last_name()  const {
	return last_name;
}

string Book::fetch_first_name() const {
	return first_name;
}

string Book::fetch_title_name() const {
	return title_name;
}

Book::Category Book::fetch_category_name() const {
	return category;
}

istream& operator >>(istream& input, Book& object)
{
    getline(input, object.nothing, ' '); //eliminates the space- no spaces required for codecheck.
    getline(input, object.isbn_number,  ','); //scans until ',';
    getline(input, object.last_name,  ',');//scans until ',';
    getline(input, object.first_name, ',');//scans until ',';
    getline(input, object.title_name, ',');//scans until ',';

    string category_string;
    getline(input, category_string);

    object.category = Book::Category::NONE;

    if (category_string == "fiction"){
    	object.category = Book::Category::FICTION;
    }
    else if (category_string == "history") {
    	object.category = Book::Category::HISTORY;
    }
    else if (category_string == "technical"){
    	object.category = Book::Category::TECHNICAL;
    }


/*    switch(category_string){
    case "fiction": object.category=Book::Category::FICTION;
    		break;
    case "history": object.category=Book::Category::HISTORY;
        	break;
    case "Technical": object.category=Book::Category::TECHNICAL;
        	break;


    }
*/
    return input;
}

ostream& operator <<(ostream& output, const Book::Category& category)
{
	if(category==Book::Category::FICTION){
		output<<"fiction";
	}
	else if(category==Book::Category::HISTORY){
		output<<"history";
	}
	else if(category==Book::Category::TECHNICAL){
		output<<"technical";
	}
	else if(category==Book::Category::NONE){
		output<<"none";
	}
    return output;
}

ostream& operator <<(ostream& output, const Book& object) //overloading extraction operator, this produces the desired pattern
{
	output << "Book{ISBN=" << object.isbn_number << ", last=" << object.last_name
         << ", first=" << object.first_name << ", title=" << object.title_name
         << ", category=" << object.category << "}";
    return output;
}


