//============================================================================
// Name        : Book.h
// Author      : Prashanth_Rajasekar
// Version     :
// Copyright   : Book_Catalogue
// Description : Hello World in C++, Ansi-style
//============================================================================


#ifndef BOOK_H_
#define BOOK_H_

#include <iostream>
#include <string>
using namespace std;


class Book
{
public:

    enum class Category { FICTION, HISTORY, TECHNICAL, NONE };

    Book(); //default constructor

    Book(string isbn_number, string last_name, string first_name, string title_name, Category category);

    ~Book(); //destrutor

    string fetch_isbn_number() const;

    string fetch_last_name() const;

    string fetch_first_name() const;

    string fetch_title_name() const;

    Category fetch_category_name() const;

    friend istream& operator >>(istream& ins, Book& emp);

    friend ostream& operator <<(ostream& outs, const Book& emp);

private:
    string nothing="";
    string isbn_number="";        // ISBN
    string last_name="";        // author's last name
    string first_name="";       // author's first name
    string title_name="";       // book title
    Category category;  // book category
};


ostream& operator <<(ostream& outs, const Book::Category& category);

#endif /* EMPLOYEE_H_ */
