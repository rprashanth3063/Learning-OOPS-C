//============================================================================
// Name        : BookApp.cpp
// Author      : Prashanth_Rajasekar
// Version     :
// Copyright   : Book_Catalogue
// Description : Hello World in C++, Ansi-style
//============================================================================


#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include "Book.h"

using namespace std;

// Status codes.
enum class StatusCode {OK, DUPLICATE, NOT_FOUND, INVALID_COMMAND};

StatusCode task(const char tasks, istream &input, vector<Book>& catalog);

StatusCode adder(istream &input, vector<Book>& catalog, int &index);

StatusCode negator(istream &input, vector<Book>& catalog, Book& book);

vector<int> compare_list(istream &input, vector<Book>& catalog);

vector<int> find_isbn(const string last, const vector<Book>& catalog);

vector<int> find_author(const string last, const vector<Book>& catalog);

vector<int> find_category(string category_string, const vector<Book>& catalog);

int binary_search(const string isbn, const vector<Book>& catalog);


const string INPUT_FILE_NAME = "commands.in";

/**
 * The main. Open the command input file and loop to process commands.
 */
int main()
{
    // Open the input file.
    ifstream input;
    input.open(INPUT_FILE_NAME);
    if (input.fail())
    {
        cout << "Failed to open " << INPUT_FILE_NAME << endl;
        return -1;
    }

    vector<Book> catalog;  // book catalog

    char command;
    input >> command;  // read the first command

    /**
     * Loop to read commands until the end of file.
     */
    while (!input.fail())
    {
        cout << endl << command << " ";

        StatusCode status_code_value=task(command, input, catalog);
        if (status_code_value != StatusCode::OK){

        		if(status_code_value==StatusCode::DUPLICATE){
        			cout << "*** Duplicate ISDN ***" << endl;
        		}
        		else if(status_code_value==StatusCode::NOT_FOUND){
        			cout << "*** Book not found ***" << endl;
        		}
        		else if(status_code_value==StatusCode::INVALID_COMMAND){
        			cout << "*** Invalid command ***" << endl;
        		}
        		}
        input >> command;
    }
    return 0;
}

StatusCode task(const char tasks, istream &input, vector<Book>& catalog_vector)
{
    StatusCode acknowledgement;
    Book book;
    int position;
    if(tasks=='+'){
    		acknowledgement=adder(input, catalog_vector, position);
    		book=catalog_vector[position];
    		cout << "Inserted at index " << position << ": " << book << endl;
    }
    else if(tasks=='-'){
    		acknowledgement = negator(input, catalog_vector, book);
    		cout << "Removed " << book << endl;
    }
    else if(tasks=='?'){
    		vector<int> matches = compare_list(input, catalog_vector);
    	    for (int i : matches) //range based for loop in c++;
    		{

    	    	cout << catalog_vector[i] << endl;

    	    }
    	    acknowledgement = StatusCode::OK;
    }
    else{
    		string dummy_storage;
    	    getline(input, dummy_storage);
    		acknowledgement = StatusCode::INVALID_COMMAND;;
    }
    return acknowledgement;
}

StatusCode adder(istream &input, vector<Book>& catalog_vector, int& position)
{

    Book object;
    input >> object;

    string isbn_copy = object.fetch_isbn_number();
    position = 0;
    while ((position < catalog_vector.size()) && (isbn_copy > catalog_vector[position].fetch_isbn_number())){
    	position++;
    }

    if (position >= catalog_vector.size())
    {
    	catalog_vector.push_back(object); //adding objects to the end of the vector.
        return StatusCode::OK;
    }
    else if (isbn_copy == catalog_vector[position].fetch_isbn_number())
    { //checkind duplicacy
        return StatusCode::DUPLICATE;
    }
    else
    {
    	catalog_vector.insert(catalog_vector.begin() + position, object);
        return StatusCode::OK;
    }
}

StatusCode negator(istream &input, vector<Book>& catalog_vector, Book& object)
{
    string isbn;
    input >> isbn;

    // Look for the book record with a matching ISBN.
    int index = binary_search(isbn, catalog_vector);
    if (index <0)
    {
    	object = Book(isbn, "", "", "", Book::Category::NONE); //setting all the parametres to null.
        return StatusCode::NOT_FOUND;
    }

    // Remove the matching book from the catalog.
    object = catalog_vector[index];
    catalog_vector.erase(catalog_vector.begin() + index); //vector erase function called - element removal..
    return StatusCode::OK;
}

vector<int> compare_list(istream &input, vector<Book>& catalog_vector)
{
    vector<int> compare_vector;
    string str;
    getline(input, str);

    if (str == ""){
    	    cout << "All books in the catalog:" << endl;
    	    for (int i = 0; i < catalog_vector.size(); i++) compare_vector.push_back(i);
    }
    else if (str.find("isbn=") != str.npos){
        string isbn = str.substr(str.find("=") + 1);
        compare_vector = find_isbn(isbn, catalog_vector);
    }
    else if (str.find("author=") != str.npos){
        string last = str.substr(str.find("=") + 1);
        compare_vector = find_author(last, catalog_vector);
    }
    else if (str.find("category=") != str.npos){
        string category = str.substr(str.find("=") + 1);
        compare_vector = find_category(category, catalog_vector);
    }
    return compare_vector;
}

vector<int> find_isbn(const string isbn_number, const vector<Book>& catalog_vector){
    vector<int> compare_vector;

    cout << "Book with ISBN " << isbn_number << ":" << endl;

    int index = binary_search(isbn_number, catalog_vector); //searches for isbn within the catalog_vector
    if (index >=0) {
    	compare_vector.push_back(index);
    }

    return compare_vector;
}

vector<int> find_author(const string last_name, const vector<Book>& catalog_vector){
    vector<int> compare_values;
    cout << "Books by author " << last_name << ":" << endl;
    int i=0;
    while(i<=catalog_vector.size()){ //linear search being done here
        Book book = catalog_vector[i];
        if (last_name == book.fetch_last_name()){
        	compare_values.push_back(i);
        }
        i++;
    }
    return compare_values;
}

vector<int> find_category(string category_string, const vector<Book>& catalog_vector){
    vector<int> compare_vector;
    int i=0;
    Book::Category category;
    if(category_string=="fiction"){
    		category=Book::Category::FICTION;
    }
    else if(category_string=="technical"){
    		category=Book::Category::TECHNICAL;
    }
    else if(category_string=="history"){
    		category=Book::Category::HISTORY;
    }
    else if(category_string=="none" || category_string==""){
    		category=Book::Category::NONE;
    }
    cout << "Books in category " << category << ":" << endl;

    while(i<=catalog_vector.size()-1){ //linear search being done here.
        Book book = catalog_vector[i]; //each index of the vector conains the book object.
        if (category == book.fetch_category_name()) {
        	compare_vector.push_back(i);
        }
        i++;
    }
    return compare_vector;
}

int binary_search(const string isbn_number, const vector<Book>& catalog_vector)
{	//binary search implemented as per given in the lecture pdf.
    int starting_point = 0;
    int finishing_point = catalog_vector.size();

    while (starting_point <= finishing_point){
        int middle_point = (starting_point + finishing_point)/2;
        Book book = catalog_vector[middle_point];

        if (isbn_number == book.fetch_isbn_number()){//best case. rarest case.
            return middle_point;
        }
        else if (isbn_number < book.fetch_isbn_number()){
        	finishing_point = middle_point - 1; //left half selected
        }
        else if(isbn_number>book.fetch_isbn_number()){
        	starting_point  = middle_point + 1; //right half selected.
        }
        else{
        	return -1; //if the isbn value is not found.
        }
    }
    return -1;
}



