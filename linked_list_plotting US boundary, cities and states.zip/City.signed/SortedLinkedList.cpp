//============================================================================
// Name        : SortedLinkedList.cpp
// Author      : Prashanth_Rajasekar
// Version     :
// Created on  : Mar 15, 2018
//============================================================================

#include "SortedLinkedList.h"


ostream& operator <<(ostream& output, const SortedLinkedList& linked_list){
    Node* temp_pointer;
	int row_number = 0;
    int row_value_place=0;

    //iteratively temp_pointer will be pointing to the place where the temp_pointer's link is pointing to.
    for (temp_pointer = linked_list.get_data_value(); temp_pointer != nullptr; temp_pointer = temp_pointer->link){
        if (row_number != temp_pointer->get_row_value())
        {
        		row_value_place=0;
            	while (row_number < temp_pointer->get_row_value()){
                cout << endl;
                row_number++;
            }
        }

        if (row_value_place <= temp_pointer->get_col_value()){
            while (row_value_place < temp_pointer->get_col_value()){
                cout << " ";
                row_value_place++;
            }

            cout << *temp_pointer;
            row_value_place++;

            if (temp_pointer->get_place_name().length() > 0)
            {
            		row_value_place =row_value_place + temp_pointer->get_place_name().length() + temp_pointer->get_state_name().length() + 1;
            }
        }
    }

    return output;
}

SortedLinkedList::SortedLinkedList(){
	head_pointer=nullptr;
}

//"this" refers to the object that called the function.
void SortedLinkedList::insert(Node *node){
	Node *temp_pointer;
	Node *back_pointer;
    if (this->head_pointer == nullptr){
        this->head_pointer = node;
    }

    else if (!(*node > *head_pointer)){
        node->link = this->head_pointer;
        this->head_pointer = node;
    }

    else{
    	temp_pointer = this->head_pointer;
        //traverse until the end of the linked list.
        while ((temp_pointer != nullptr) && (*node > *temp_pointer)){
        		back_pointer = temp_pointer;
            temp_pointer = temp_pointer->link;
            //prev pointer stays one step back of the temp_pointer
            //these 2 pointers will be traversing back to back.
        }
        back_pointer->link = node;
        node->link = temp_pointer;
    }
}
