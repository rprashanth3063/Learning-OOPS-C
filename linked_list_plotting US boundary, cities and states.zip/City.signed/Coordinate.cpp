//============================================================================
// Name        : Coordinate.cpp
// Author      : Prashanth_Rajasekar
// Version     :
// Created on  : Mar 15, 2018
//============================================================================

#include "Coordinate.h"

Coordinate::Coordinate(){
	MAX_LATITUDE  =   49.373112;
	MIN_LONGITUDE = -124.769867;
	lattitude=0;
	longitude=0;
}

double Coordinate::get_latitude()  const {
	return lattitude;
}

double Coordinate::get_longitude() const {
	return longitude;
}

istream& operator >>(istream& input, Coordinate& object){
    //input has both lattitude and longitude seperated by coma(,).
	//below we are parsing the two data and storing into the respective coordinates.
	//sample data in input...... 48.453197,-124.769867
	//coordinate is the object of Coordinate class.
	string temp_lattitude;
    string temp_longitude;
    getline(input, temp_lattitude, ',');
    getline(input, temp_longitude);
    object.lattitude = stod(temp_lattitude); // stod converts from string to double value.
    object.longitude = stod(temp_longitude); // stod converts from string to double value.
    return input;
}



