//============================================================================
// Name        : City.cpp
// Author      : Prashanth_Rajasekar
// Version     :
// Created on  : Mar 15, 2018
//============================================================================

#include "City.h"

City::City() {
//initialises the place_ame and state_name as empty
	place_name="";
	state_name="";
}

string City::get_place_name() const {
	return place_name;
}

string City::get_state_name() const {
	return state_name;
}

Coordinate City::get_coordinate() const {
	return coordinate;
}

ostream& operator <<(ostream& output, const City& object){
    return output << "*" << object.place_name << " " << object.state_name;

}

istream& operator >>(istream& input, City& object) {
	string temp="";//temporary place to store place_name and state_name;

    //parsing place_name and state name and coordinate
    getline(input, temp,  ',');
    object.place_name=temp;

    getline(input, temp, ',');
    object.state_name=temp;

    input >> object.coordinate;

    return input;
}

