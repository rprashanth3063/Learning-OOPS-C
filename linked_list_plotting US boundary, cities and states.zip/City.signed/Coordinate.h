//============================================================================
// Name        : Coordinate.h
// Author      : Prashanth_Rajasekar
// Version     :
// Created on  : Mar 15, 2018
//============================================================================

#ifndef COORDINATE_H_
#define COORDINATE_H_

#include <iostream>
#include <string>
using namespace std;

class Coordinate{
public:

    Coordinate();

    double get_latitude() const;
    double get_longitude() const;

    friend istream& operator >>(istream& input, Coordinate& coordinate);

    double MAX_LATITUDE=0;
    double MIN_LONGITUDE=0;

private:
    double lattitude=0;
    double longitude=0;
};
#endif
