//============================================================================
// Name        : Node.h
// Author      : Prashanth_Rajasekar
// Version     :
// Created on  : Mar 15, 2018
//============================================================================

#ifndef NODE_H_
#define NODE_H_

#include "City.h"
#include "Coordinate.h"

class Node
{
public:
    Node();
    Node(Coordinate object);
    Node(City city);

    Node *get_next() const;
    int get_row_value() const;
    int get_col_value() const;
    string get_place_name() const;
    string get_state_name() const;

    Node *link;

    //oveloading > operator./////////////////
    bool operator >(const Node& other);

    // Overloading << operator.////////////////////////
    friend ostream& operator <<(ostream& outs, const Node& object);

private:
    string place_name;
    string state_name;
    int row;
    int col;

    void convert_coordinate(const Coordinate& coordinate);
};

#endif /* NODE_H_ */
