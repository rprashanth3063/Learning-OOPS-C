//============================================================================
// Name        : SortedLinkedList.h
// Author      : Prashanth_Rajasekar
// Version     :
// Created on  : Mar 15, 2018
//============================================================================

#ifndef SORTEDLINKEDLIST_H_
#define SORTEDLINKEDLIST_H_

#include "Node.h"

class SortedLinkedList
{
public:
    SortedLinkedList(); //default constuctor

    Node *get_data_value() const {
    	return head_pointer;
    }

    void insert(Node *node);

    friend ostream& operator <<(ostream& output, const SortedLinkedList& linked_list);

private:
    Node *head_pointer;
};

#endif /* SORTEDLINKEDLIST_H_ */
