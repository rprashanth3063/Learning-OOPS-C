//============================================================================
// Name        : City.h
// Author      : Prashanth_Rajasekar
// Version     :
// Created on  : Mar 15, 2018
//============================================================================


#ifndef CITY_H_
#define CITY_H_


#include <iostream>
#include <string>

#include "Coordinate.h"

using namespace std;

class City
{
public:

    City();

    string get_place_name() const;
    string get_state_name() const;
    Coordinate get_coordinate() const;
    Coordinate coordinate;
    friend ostream& operator <<(ostream& output, const City& object);
    friend istream& operator >>(istream& input, City& object);

private:
    string place_name;
    string state_name;
};

#endif /* CITY_H_ */
