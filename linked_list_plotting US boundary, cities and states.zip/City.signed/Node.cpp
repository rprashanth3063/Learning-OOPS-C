//============================================================================
// Name        : Node.cpp
// Author      : Prashanth_Rajasekar
// Version     :
// Created on  : Mar 15, 2018
//============================================================================

#include <math.h>
#include "Node.h"

Node::Node(){
	link=nullptr;
	place_name="";
	state_name="";
	row=0;
	col=0;
}

Node::Node(Coordinate object1){
	link=nullptr;
	place_name="";
	state_name="";
    row = round(2*(object1.MAX_LATITUDE - object1.get_latitude()));
    col = round(2*(object1.get_longitude() - object1.MIN_LONGITUDE));
}

Node::Node(City city_name){
	this->link=nullptr;
	this->place_name=city_name.get_place_name();
	this->state_name=city_name.get_state_name();
    convert_coordinate(city_name.get_coordinate()); //calling convert_values function.
}

void Node::convert_coordinate(const Coordinate& object){
	double lattitude=object.get_latitude();
	double longitude=object.get_longitude();
	double max_lattitude=object.MAX_LATITUDE;
	double min_longitude=object.MIN_LONGITUDE;
	this->row = round(2*(max_lattitude - lattitude)); //rounds of the value to avoid decimals.
	this->col = round(2*(longitude - min_longitude ));//rounds of the value to avoid decimals.
	//now the col and row variable values will not have decimal points.
}

Node *Node::get_next() const {
	return this->link;
}

int Node::get_row_value() const {
	return this->row;
}

int Node::get_col_value() const {
	return this->col;
}

string Node::get_place_name() const {
	return this->place_name;
}

string Node::get_state_name() const {
	return this->state_name;
}

//defining overloading > operator
bool Node::operator >(const Node& object){
    if((this->row > object.row) || ((this->row == object.row) && (this->col > object.col))){
    	return true;
    }
    else{return false;}
}

ostream& operator <<(ostream& output, const Node& object){
    if(object.place_name.length()==0){
    		output << "#";
    }
    else{
    		output << "*" << object.place_name << " " << object.state_name;
    }
    return output;
}
