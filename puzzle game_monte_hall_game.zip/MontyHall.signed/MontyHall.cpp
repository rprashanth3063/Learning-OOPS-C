//============================================================================
// Name        : MonteHallProlem.cpp
// Author      : Prashanth_Rajasekar
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;
typedef int Door;

///////////////////////////////functions being used declared below///////////////////////////////
Door hideCar();//hides thecar randomly behind any of the 3 doors.

Door openDoor();// randomly opens any of the 2 doors based on the first door opened..

Door makeFirstChoice(); //randomly chooses any of the 3 doors as the first choice.

Door makeSecondChoice(); //makes the second choice based on the previous selection made.

Door simulate(int SIMULATION_COUNT); // this function calls all the above functions declared above.
////////////////////////////////////////////////////////////////////////////////////////////////


const int SIMULATION_COUNT = 100;
int hidden_car_door_number;
int first_choice_door;
int second_choice_door;
int win_first_count=0; // stores the number of wins at first chance to calculate the ratio.
int win_second_count=0;// stores the number of wins at the second choice.
int door_to_open;


int main()
{
	srand(time(0));
	cout<<"    #     Car  First   Opened  Second     Win     Win"<<endl; // labels.
	cout<<"          here choice  door    choice   First  Second"<<endl; // labels.
	cout<<endl;

	simulate(SIMULATION_COUNT); //simulation function called. simulation will be for 100 counts.

    cout<<endl;
    cout<<setw(5)<<win_first_count<<" wins if stay with the first choice"<<endl;
    cout<<setw(5)<<win_second_count<<" wins if switch to the second choice"<<endl;
    cout<<endl;

    double ratio=static_cast<double>(win_second_count)/win_first_count; //datatype conversion
    cout.precision(2);
    cout.setf(ios::showpoint);
    cout<<"Win ratio of switch over stay: "<<ratio; //ratio will be displayed here.
}



/////////////////////////////////function definition stated below///////////////////////

Door simulate(int SIMULATION_COUNT){

	///////////// Running the simulations using for loop until simulation count reaches.
	    for (int i = 1; i <= SIMULATION_COUNT; i++) {
	    	hidden_car_door_number=hideCar();  //door which is having the car.
	    	first_choice_door=makeFirstChoice(); //first choice made here.
	    	door_to_open=openDoor();				//any of the rest two doors are opened.
	    	second_choice_door=makeSecondChoice(); // second choice made based on the first_choice_door and door_to_open.

	    	///////////conditions to print index in aligned manner.///////////
	    	if(i<10){
	    		cout<<setw(5)<<i;
	    	}
	    	else if(i>9 && i<100){
	    		cout<<setw(5)<<i;
	    	}
	    	else if(i>99){
	    		cout<<setw(5)<<i;
	    	}

	    		if(hidden_car_door_number==first_choice_door){
	    			win_first_count++;  ///////counts the number of wins at first choice.
	    			cout<<setw(8)<<hidden_car_door_number<<setw(8)<<first_choice_door<<setw(8)<<door_to_open<<setw(8)<<second_choice_door<<setw(8)<<"yes"<<endl;
	    		}
	    		else{
	    			win_second_count++;
	    			cout<<setw(8)<<hidden_car_door_number<<setw(8)<<first_choice_door<<setw(8)<<door_to_open<<setw(8)<<second_choice_door<<setw(16)<<"     yes"<<endl;
	    		}

	    } ////////////// for loop ends here, loop successfully ran for 100 simulation count..
	return 1;
}

Door hideCar(){ //randmly hiding the car behind the 3 doors.
	hidden_car_door_number= (rand()%3) + 1;
	return hidden_car_door_number;
}

Door makeFirstChoice(){ // rnadmoly picking door 1 or door 2 or door 3.
	 first_choice_door= (rand()%3)+1;
	 return first_choice_door;
}

Door openDoor(){
	int returnvalue;
	if(hidden_car_door_number==1 && first_choice_door==1){
		returnvalue= rand()%2+2; //randomly choos between 2 and 3.
	}

	else if(hidden_car_door_number==3 && first_choice_door==3){
		returnvalue= rand()%2 + 1; //randomly choose between 1 and 2.
	}

	else if(hidden_car_door_number==2 && first_choice_door==2){
		int arr[]={1,3};		//randomly choosing between 1 and 3 which are stored in an array.
		int index=rand()%2;
		return arr[index];
	}

	if(hidden_car_door_number!=first_choice_door){ // condition, when first choice doest have the car.
		if(hidden_car_door_number==1 && first_choice_door==2){
			returnvalue= 3;
		}
		else if(hidden_car_door_number==2 && first_choice_door==1){
			returnvalue= 3;
		}
		else if(hidden_car_door_number==2 && first_choice_door==3){
			returnvalue= 1;
		}
		else if(hidden_car_door_number==3 && first_choice_door==2){
			returnvalue= 1;
		}
		else if(hidden_car_door_number==1 && first_choice_door==3){
			returnvalue= 2;
		}
		else if(hidden_car_door_number==3 && first_choice_door==1){
			returnvalue= 2;
		}
	}
	return returnvalue;
 }
Door makeSecondChoice(){ // makes the second choice of the contestant according to the choices made previously.
	 int return_second_choice;
	 if(first_choice_door==1 && door_to_open==2){
		 return_second_choice= 3;
	 }
	 else if(first_choice_door==2 && door_to_open==1){
		 return_second_choice= 3;
	 }
	 else if(first_choice_door==2 && door_to_open==3){
		 return_second_choice= 1;
	 }
	 else if(first_choice_door==3 && door_to_open==2){
		 return_second_choice= 1;
	 }
	 else if(first_choice_door==1 && door_to_open==3){
		 return_second_choice= 2;
	 }
	 else if(first_choice_door==3 && door_to_open==1){
		 return_second_choice= 2;
	 }

	 return return_second_choice;
 }
